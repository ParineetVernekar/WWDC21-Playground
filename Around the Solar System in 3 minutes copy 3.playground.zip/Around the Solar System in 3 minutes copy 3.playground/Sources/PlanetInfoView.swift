
import SwiftUI
import SceneKit

@available(iOS 13.0, *)
public struct PlanetInfoView: View {
    public var planetName : String
    public var planetInfo : Planet
    public var body: some View {
        VStack{
                    HStack {
                        Spacer()
                        VStack {
                            Image(uiImage: (UIImage(named: "\(planetInfo.planetImgName).jpg") ?? UIImage(systemName: "moon.stars.fill")!))
                                .resizable()
                                .frame(width: 100, height: 100, alignment: .center)
                                .padding(.top)
                            Text(planetInfo.planetImgCaption)
                                .font(.caption)
                        }
                        Text(planetInfo.displayedName)
                            .font(.largeTitle)
                            .padding(.vertical)
                        Spacer()
                    }
                    Text(planetInfo.information)
                        .padding()
                    VStack{
                        Text("Did you know?")
                            .underline()
                            .font(.title2)
                        ForEach(planetInfo.facts, id: \.self){ fact in
                            Text(fact)
                                .padding(.top)
                                .lineLimit(nil)
                                

                        }
                        Spacer()
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 10))

        //            VStack {
        //                List{
        //                    ForEach(planetInfo.facts, id: \.self) { fact in
        //                        Text(fact)
        //                    }
        //                }
        //            }
                }
        .background(Color.init(red: 0.91, green: 0.97, blue: 0.93))
                .ignoresSafeArea()
                .frame(width: .infinity, height: .infinity, alignment: .center)
    }
    
    
    public init(planetName : String, planetInfo : Planet){
        self.planetName = planetName
        self.planetInfo = planetInfo
    }
}

@available(iOS 13.0, *)
public struct planetInfoView_Previews: PreviewProvider {
    public static var previews: some View {
        PlanetInfoView(planetName: "Mercury", planetInfo: planets[4])
    }
}
