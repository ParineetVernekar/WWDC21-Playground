import Foundation
import UIKit
import SceneKit
import ARKit
import SwiftUI

public class ExploreViewController: UIViewController, ARSCNViewDelegate {
    
    public init(toScaleSceneView: ARSCNView = ARSCNView(), name : String, textureName : String) {
        self.toScaleSceneView = toScaleSceneView
        self.name = name
        self.textureName = textureName
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var toScaleSceneView = ARSCNView()
    var name : String
    var textureName : String
    
    var planet = Planet(radius: 0.05,
                        position: SCNVector3(x: 0, y: 0, z: -0.4),
                        nodeName: "Node",
                        
                        textNodeName: "TextNode",
                        textPosition: SCNVector3(x: 0, y: 0.06, z: -0.4),
                        textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
                        
                        displayedName: " ",
                        imgName: " ",
                        planetImgName: " ",
                        planetImgCaption: " ",
                        
                        information: "This planet was created by you! I hope you enjoyed this playground, and I hope you learned all about our Solar System. Thank you for taking the time to use it, and I hope it all ran smooothly.",
                        facts: ["This is your planet!"])
    
    @objc func toScaleButtonAction(sender: UIButton!){
        self.view = toScaleSceneView
    }
    
    
    func planetRenderer(){
        for planet in planets{
            let scnPlanet = SCNSphere(radius: planet.radius)
            let planetMaterial = SCNMaterial()
            planetMaterial.diffuse.contents = UIImage(named: "\(planet.imgName).jpg" )
            scnPlanet.materials  = [planetMaterial]
            let planetNode = SCNNode()
            planetNode.position = planet.position
            planetNode.geometry = scnPlanet
            planetNode.name = planet.nodeName
            
            let planetText = SCNText(string: planet.displayedName, extrusionDepth: 1.0)
            planetText.firstMaterial?.diffuse.contents = UIColor.red
            let planetTextNode = SCNNode(geometry: planetText)
            planetTextNode.position = planet.textPosition
            planetTextNode.scale = planet.textScale
            planetTextNode.name = planet.textNodeName
            
            toScaleSceneView.scene.rootNode.addChildNode(planetNode)
            toScaleSceneView.scene.rootNode.addChildNode(planetTextNode)
            
            if planet.nodeName == "saturnNode"{
                let saturnRings = SCNTorus(ringRadius: 0.068232, pipeRadius: 0.0025)
                let saturnRingMaterial = SCNMaterial()
                saturnRingMaterial.diffuse.contents = UIImage(named: "saturnRings.jpg")
                saturnRings.materials = [saturnRingMaterial]
                let saturnRingNode = SCNNode()
                saturnRingNode.position = SCNVector3(x: 0, y: 0, z: -1.275)
                saturnRingNode.geometry = saturnRings
                let piByFour = Float.pi / 8
                saturnRingNode.eulerAngles.z = -piByFour
                toScaleSceneView.scene.rootNode.addChildNode(saturnRingNode)
            }
        }
        
        planet.displayedName = name
        planet.imgName = "\(textureName).jpg"
        planet.nodeName = "\(name)Node"
        planet.textNodeName = "\(name)TextNode"
        planet.planetImgCaption = "\(name) by you!"
        
        let scnPlanet = SCNSphere(radius: planet.radius)
        let planetMaterial = SCNMaterial()
        planetMaterial.diffuse.contents = UIImage(named: "\(textureName).jpg" )
        scnPlanet.materials  = [planetMaterial]
        
        let planetNode = SCNNode()
        planetNode.position = planet.position
        planetNode.geometry = scnPlanet
        planetNode.name = name
        
        let planetText = SCNText(string: name, extrusionDepth: 1.0)
        planetText.firstMaterial?.diffuse.contents = UIColor.red
        let planetTextNode = SCNNode(geometry: planetText)
        planetTextNode.position = planet.textPosition
        planetTextNode.scale = planet.textScale
        planetTextNode.name = planet.nodeName
        
        toScaleSceneView.scene.rootNode.addChildNode(planetNode)
        toScaleSceneView.scene.rootNode.addChildNode(planetTextNode)
        
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.toScaleSceneView.delegate = self
        self.view = toScaleSceneView
        self.toScaleSceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        planetRenderer()
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let touchLocation = touch.location(in: toScaleSceneView)
            let results = toScaleSceneView.hitTest(touchLocation, options: [SCNHitTestOption.searchMode : 1])
            for _ in results.filter({$0.node.name != nil}) {
                let vc = UIHostingController(rootView: PlanetInfoView(planetName: planet.displayedName, planetInfo: planet))
                self.present(vc, animated: true, completion: nil)
                
            }
        }
    }
    
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        toScaleSceneView.session.run(configuration)
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        toScaleSceneView.session.pause()
    }
    
}
