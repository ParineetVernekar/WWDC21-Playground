import Foundation
import SwiftUI

public struct RocketPath : Shape{
    public func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX + 75, y: rect.minY + 150))
        path.addCurve(to: CGPoint(x: rect.midX, y: rect.maxY - 130), control1: CGPoint(x: rect.minX + 50, y: rect.minY + 100), control2: CGPoint(x: rect.midX, y: rect.maxY - 95))

        path.addCurve(to: CGPoint(x: rect.maxX - 100, y: rect.midY + 40), control1: CGPoint(x: rect.midX, y: rect.maxY - 130), control2: CGPoint(x: rect.maxX, y: rect.midY))

        return path
    }
    public init() {}

}
