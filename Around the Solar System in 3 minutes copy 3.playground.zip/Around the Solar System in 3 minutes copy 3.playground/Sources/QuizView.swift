import Foundation
import SwiftUI
import PlaygroundSupport

public struct QuizView: View {
    @State var answered = false
    @State var color = 2
    @State var answeredCorrect = false
    @State var score = 0
    @State var questionNumber = 0
    @State var finished = false
    
    var quizQuestions : [Question]
    var question : Question? {
        if questionNumber >= quizQuestions.count{
            return nil
        } else{
            return quizQuestions[questionNumber]
        }
    }
    
    var answers : [Answer]?{
        return question?.answers
    }
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]
    
    func answerTapped(_ answer : Answer){
        if answer.isTrue {
            answeredCorrect = true
            color = 0
            self.score += 1
        } else{
            color = 1
        }
    }
    
    func getBackgroundColor(color: Int) -> Color{
        if color == 0{
            return Color.green
        } else if color == 1{
            return Color.red
        } else {
            return Color.white
        }
    }
    
    public var body: some View {
        
        if !finished{
            VStack{
                HStack{
                    Spacer()
                    Text("\(question?.questionTitle ?? " ")")
                        .font(.title)
                        .padding()
                    Spacer()
                    Text("\(score) / \(quizQuestions.count)")
                        .padding()
                }
                
                if let imageAddress = question?.imageAddress {
                    Image(imageAddress)
                }
                
                if let answers = question?.answers{
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(answers, id: \.self) { answer in
                            Button {
                                answered = true
                                answerTapped(answer)
                            } label: {
                                Text(answer.answer)
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .background(RoundedRectangle(cornerRadius: 20)
                                                    .frame(width: 200, height: 100, alignment: .center)
                                    )
                                    .frame(width: 200, height: 100, alignment: .center)
                            }
                            .disabled(answered)
                        }
                    }
                    .frame(minWidth: 500, minHeight: 300)
                }
                
                if questionNumber == quizQuestions.count - 1{
                    Button{
                        self.color = 2
                        self.answered = false
                        self.questionNumber += 1
                        if questionNumber >= quizQuestions.count{
                            self.finished = true
                        }
                    } label:{
                        Text("Complete Quiz")
                    }
                    .disabled(!answered)
                    
                } else{
                    Button{
                        self.color = 2
                        self.answered = false
                        self.questionNumber += 1
                        if questionNumber >= quizQuestions.count{
                            self.finished = true
                        }
                    } label:{
                        Text("Next Question")
                    }
                    .disabled(!answered)
                }
            }
            .frame(minWidth: 500, maxWidth: .infinity, minHeight: 500, maxHeight: .infinity)
            .ignoresSafeArea()
            .background(getBackgroundColor(color: self.color))
        } else{
            FinishedView(score: $score, questionNumber: $questionNumber, finished: $finished, noOfQuestions: quizQuestions.count)
        }
        
    }
    
    public init(quizQuestions : [Question]){
        self.quizQuestions = quizQuestions
    }
}


struct FinishedView: View {
    
    @Binding var score : Int
    @Binding var questionNumber : Int
    @Binding var finished : Bool
    var noOfQuestions : Int
    
    var body: some View {
        ZStack {
            Color.init(red: 0.91, green: 0.97, blue: 0.93)
            RoundedRectangle(cornerRadius: 25)
                .stroke(Color.init(red: 0.20, green:0.396, blue: 0.541), lineWidth: 6)
                .padding(25)
                .frame(minWidth: 500, maxWidth: .infinity, minHeight: 500, maxHeight: .infinity)
            
            VStack{
                if score <= (noOfQuestions / 3){
                    Text("You got \(score) out of \(noOfQuestions)! Think you could do better? Try again!")
                        .frame(width: 450, height: 100, alignment: .center)
                        .font(.title2)
                        .padding()
                    Button{
                        self.score = 0
                        self.questionNumber = 0
                        self.finished = false
                    } label:{
                        Text("Start again")
                        
                    }
                } else if (score >= (noOfQuestions / 3)) && (score <= (2*noOfQuestions/3)) {
                    Text("🥳")
                        .font(.system(size: 100))
                    Text("Congratulations! You got \(score) out of \(noOfQuestions)!")
                        .font(.title)
                    
                } else{
                    Text("AMAZING")
                        .font(.title)
                }
                
                Button{
                    PlaygroundPage.current.navigateTo(page: .pageReference(reference: "Explore"))
                } label:{
                    Text("Go to Level 3 - Explore")
                    
                }
                
            }
            .frame(minWidth: 500, maxWidth: .infinity, minHeight: 500, maxHeight: .infinity)
            .ignoresSafeArea()
            
            //                .background(Color.init(red: 0.91, green: 0.97, blue: 0.93))
        }
    }
}
