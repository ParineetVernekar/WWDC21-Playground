import Foundation
import UIKit
import SceneKit
import ARKit
import SwiftUI

public class ARViewController: UIViewController, ARSCNViewDelegate {
    
    public init(toScaleSceneView: ARSCNView = ARSCNView(), clickedPlanets: [String] = []) {
        self.toScaleSceneView = toScaleSceneView
        self.clickedPlanets = clickedPlanets
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
//    @IBOutlet var toScaleSceneView: ARSCNView!
    var toScaleSceneView = ARSCNView()
    
    var clickedPlanets : [String] = []

    @objc func toScaleButtonAction(sender: UIButton!){
        self.view = toScaleSceneView
    }
    
    @objc func nextButtonAction(sender: UIButton!){
        let vc = UIHostingController(rootView: NextButtonView())
        self.present(vc, animated: true, completion: nil)        
    }
    
    func planetRenderer(){
        for planet in planets{
            let scnPlanet = SCNSphere(radius: planet.radius)
            let planetMaterial = SCNMaterial()
            planetMaterial.diffuse.contents = UIImage(named:"\(planet.imgName).jpg" )
            scnPlanet.materials  = [planetMaterial]
            let planetNode = SCNNode()
            planetNode.position = planet.position
            planetNode.geometry = scnPlanet
            planetNode.name = planet.nodeName
            
            let planetText = SCNText(string: planet.displayedName, extrusionDepth: 1.0)
            planetText.firstMaterial?.diffuse.contents = UIColor.red
            let planetTextNode = SCNNode(geometry: planetText)
            planetTextNode.position = planet.textPosition
            planetTextNode.scale = planet.textScale
            planetTextNode.name = planet.textNodeName
            
            toScaleSceneView.scene.rootNode.addChildNode(planetNode)
            toScaleSceneView.scene.rootNode.addChildNode(planetTextNode)
            
            if planet.nodeName == "saturnNode"{
                let saturnRings = SCNTorus(ringRadius: 0.068232, pipeRadius: 0.0025)
                let saturnRingMaterial = SCNMaterial()
                saturnRingMaterial.diffuse.contents = UIImage(named: "saturnRings.jpg")
                saturnRings.materials = [saturnRingMaterial]
                let saturnRingNode = SCNNode()
                saturnRingNode.position = SCNVector3(x: 0, y: 0, z: -1.275)
                saturnRingNode.geometry = saturnRings
                let piByFour = Float.pi / 8
                saturnRingNode.eulerAngles.z = -piByFour
                toScaleSceneView.scene.rootNode.addChildNode(saturnRingNode)
            }
        }
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.toScaleSceneView.delegate = self
        self.view = toScaleSceneView
        
        self.toScaleSceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
        planetRenderer()
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let touchLocation = touch.location(in: toScaleSceneView)
            let results = toScaleSceneView.hitTest(touchLocation, options: [SCNHitTestOption.searchMode : 1])
            for result in results.filter({$0.node.name != nil}) {
                if let planet = planets.first(where: { $0.nodeName == result.node.name }) ?? planets.first(where: { $0.textNodeName == result.node.name }){
                    let vc = UIHostingController(rootView: PlanetInfoView(planetName: planet.displayedName, planetInfo: planet))
                    self.present(vc, animated: true, completion: nil)
                    clickedPlanets.append(planet.displayedName)
                    showNextButton()
                }
            }
            UserDefaults.standard.setValue(clickedPlanets, forKey: "clickedPlanets")
        }
    }
    
    func showNextButton(){
        if clickedPlanets.count >= 1{
            let nextButton = UIButton(frame: CGRect(x: 210, y:100, width: 100, height: 50))
            nextButton.backgroundColor = .white
            nextButton.setTitleColor(.red, for: .normal)
            nextButton.layer.cornerRadius = 5
            nextButton.layer.borderWidth = 1
            nextButton.layer.borderColor = UIColor.black.cgColor
            nextButton.setTitle("Next", for: .normal)
            nextButton.addTarget(self, action: #selector(nextButtonAction), for: .touchUpInside)
            toScaleSceneView.addSubview(nextButton)
            nextButton.centerXAnchor.constraint(equalTo: toScaleSceneView.centerXAnchor).isActive = true
        }
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        toScaleSceneView.session.run(configuration)
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        toScaleSceneView.session.pause()
    }
    
}
