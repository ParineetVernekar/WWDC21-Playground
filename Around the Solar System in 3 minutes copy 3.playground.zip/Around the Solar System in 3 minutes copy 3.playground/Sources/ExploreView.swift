import Foundation
import SwiftUI
import PlaygroundSupport

public struct ExploreView: View {
    @State var name : String = " "
    @State var textureName : String = " "
    
    public var body: some View {
        ScrollView{
            Text("Create your own planet, complete with a custom name and texture! See it in your own room, right there! Ready? Press the button below, and let's go!")
                TextField("Planet Name", text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                Picker(selection: $textureName, label: Text("Select texture")) {
                    Text("Ceres").tag("Ceres")
                    Text("Makemake").tag("Makemake")
                    Text("Haumea").tag("Haumea")
                    Text("Eris").tag("Eris")
                }.pickerStyle(WheelPickerStyle())
                
                Button(action: {
                    PlaygroundPage.current.setLiveView(ExploreViewController(name : name, textureName : textureName))
                }) {
                    Text("Explore - create your own planet!")
                        .padding()
                }
            
        }
        .background(Color.init(red: 0.91, green: 0.97, blue: 0.93))
        .ignoresSafeArea()
        .frame(minWidth: 300, idealWidth: 500, maxWidth: .infinity, minHeight: 300, idealHeight: 500, maxHeight: .infinity, alignment: .center)
    }
    
    
    public init(){}
}

@available(iOS 13.0, *)
public struct ExploreView_previews: PreviewProvider {
    public static var previews: some View {
        ExploreView()
    }
}
