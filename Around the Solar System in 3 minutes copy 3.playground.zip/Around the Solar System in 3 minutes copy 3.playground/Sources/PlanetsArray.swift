
import Foundation
import SceneKit

public let planets = [
    Planet(radius: 0.069634,
           position: SCNVector3(x: 0, y: 0, z: 0.199062),
           nodeName: "sunNode",
           
           textNodeName: "sunTextNode",
           textPosition:  SCNVector3(x: 0, y: 0.074634, z: 0.199062),
           textScale: SCNVector3(x: 0.0025, y: 0.0025, z: 0.0025),
           
           displayedName: "The Sun",
           imgName: "sun",
           planetImgName: "sunPhoto",
           planetImgCaption: "Photo of the sun",
           
           information: "The Sun is in the centre of our Solar System, and can fit 1,000,000 Earths inside of it! The outer part of the Sun is around 5,000°C, whilst the middle is over 15 million Celsius. Although the Sun is massive, it's only a yellow dwarf star; there are much bigger stars in the Universe!",
           facts: ["The Sun is not a planet, but it is a star", "The Sun is around 4.5 Billion Years old", "The Sun's gravity holds the solar system together"]),
    Planet(radius: 0.0024397,
           position: SCNVector3(x: 0, y: 0, z: 0.107662),
           nodeName: "mercuryNode",
           
           textNodeName: "mercuryTextNode",
           textPosition: SCNVector3(x: 0, y: 0.0029397, z: 0.107662),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
           
           displayedName: "Mercury",
           imgName: "mercury",
           planetImgName: "mercuryPlanet",
           planetImgCaption: "Photo of Mercury",
           
           information: "Mercury is the closest planet to the Sun, and is the smallest planet in the Solar System. It is also a rocky planet, like our moon, and the atmosphere is very thin, consisting of oxygen, sodium, hydrogen, helium, potassium and more. ",
           facts: ["Mercury is named after the Roman God of Commerce", "Mercury has no moons", "1 Rotation around the Sun takes 59 Earth days"]),
    Planet(radius: 0.0060518,
           position: SCNVector3(x: 0, y: 0, z: 0.0414),
           nodeName: "venusNode",
           
           textNodeName: "venusTextNode",
           textPosition: SCNVector3(x: 0, y: 0.0065518, z: 0.0414),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
           
           displayedName: "Venus",
           imgName: "venus",
           planetImgName: "venusPlanet",
           planetImgCaption: "Photo of Venus",
           
           information: "Venus is a similar size to Earth, however it has no moons and has a much higher air pressure. It is also hotter than Mercury, even though it's further from the Sun. This is because there's an intense greenhouse effect. It's also named after the Roman Goddess of Love and Beauty, and is the only planet named after a female figure.",
           facts: ["Venus was the first planet to be explored by a spacecraft", "One day on Venus is longer than a year!", "Venus' surface temeperature is around 465°C"]),
    Planet(radius: 0.006371,
           position: SCNVector3(x: 0, y: 0, z: 0),
           nodeName: "earthNode",
           
           textNodeName: "earthTextNode",
           textPosition: SCNVector3(x: 0, y: 0.006871, z: 0),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
           
           displayedName: "Earth",
           imgName: "earth",
           planetImgName: "earthPlanet",
           planetImgCaption: "Photo of Earth",
           
           information: "Earth, our home planet, is the 3rd planet from the Sun and the only planet known to have life, and the only one known to have liquid water. Earth is named after the Germanic word for 'the ground', although Earth has 70% of its surface covered in water. There's a protective atmosphere above Earth, which is thick enough to burn up many meteroites before they reach the surface. Earth's axis of rotation is at 23.4 degrees, which is why we have seasons. Whenever a hemisphere is tilted towards the Sun, it experiences Summer, and vice versa.",
           facts: ["Earth travels at 18.5 miles per second!", "Earth is the only planet in our Solar System not named after a Greek or Roman deity", "The crust of the Earth is, on average, 19 miles thick!"]),
    Planet(radius: 0.0033895,
           position: SCNVector3(x: 0, y: 0, z: -0.07384),
           nodeName: "marsNode",

           textNodeName: "marsTextNode",
           textPosition: SCNVector3(x: 0, y: 0.006871, z: -0.07384),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
           
           displayedName: "Mars",
           imgName: "mars",
           planetImgName: "marsPlanet",
           planetImgCaption: "Photo of Mars",
           
           information: "Mars is the closest planet to Earth, and is also the only planet that is thought to be inhabited purely by robots. It's called the Red Planet because of rusty iron in the ground, and has 2 moons, called Phobos and Deimos",
           facts: ["Mars is named after the Roman God of war", "Some debris from Mars has been found on Earth", "It take 687 Earth days for Mars to orbit the Sun"]),
    Planet(radius: 0.06911,
           position: SCNVector3(x: 0, y: 0, z: -0.62873),
           nodeName: "jupiterNode",

           textNodeName: "jupiterTextNode",
           textPosition: SCNVector3(x: 0, y: 0.07011, z: -0.62873),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
           
           displayedName: "Jupiter",
           imgName: "jupiter",
           planetImgName: "jupiterPlanet",
           planetImgCaption: "Photo of Jupiter",
           
           information: "Jupiter is the largest planet in the Solar System, being over 318 times the size of Earth. It's also the fastest spinning planet in the Solar System, and it takes around 10 hours to complete a rotation on its axis. Jupiter's magnetic field is also 14 times stronger than Earth",
           facts: ["Jupiter has rings, although they are very faint.", "Jupiter has 79 moons!", "7 spacecraft have visited Jupiter"]),
    Planet(radius: 0.058232,
           position: SCNVector3(x: 0, y: 0, z: -1.275),
           nodeName: "saturnNode",

           textNodeName: "saturnTextNode",
           textPosition: SCNVector3(x: 0, y: 0.07011, z: -1.275),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
           
           displayedName: "Saturn",
           imgName: "saturn",
           planetImgName: "saturnPlanet",
           planetImgCaption: "Photo of Saturn",
           
           information: "Saturn has 150 moons, which are all frozen. It's named after the Roman god Saturnus, and has the fastest winds of any other planet in the Solar System. Also, one of Saturn's moons, Enceladus, could contain life, because NASA's Cassini discovered ice geysers blasting out of it's southern pole.",
           facts: ["It takes 29 Earth years for Saturn to orbit the Sun", "The interior of Saturn reaches temperatures of 11,700°C", "Only 4 spacecraft have visited Saturn"]),
    Planet(radius: 0.025362,
           position: SCNVector3(x: 0, y: 0, z: -2.72395),
           nodeName: "uranusNode",

           textNodeName: "uranusTextNode",
           textPosition: SCNVector3(x: 0, y: 0.030362, z: -2.72395),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),

           displayedName: "Uranus",
           imgName: "uranus",
           planetImgName: "uranusPlanet",
           planetImgCaption: "Photo of Uranus",
           
           information: "Uranus is the first planet found with a telescope. William Herschel thought it was a comet, before realising it was a planet. However only 1 spacecraft (Voyager 2) has flown by Uranus. Uranus is named after the Greek God of the Sky. Uranus' moons are named after characters created by William Shakespeare and Alexandar Pope.",
           facts: ["Uranus is the coldest planet in the Solar System", "Uranus has a set of rings, however they are very dark", "Uranus has 27 moons"]),
    Planet(radius: 0.024622,
           position: SCNVector3(x: 0, y: 0, z: -4.3514),
           nodeName: "neptuneNode",
           
           textNodeName: "neptuneTextNode",
           textPosition: SCNVector3(x: 0, y: 0.029622, z: -4.3514),
           textScale: SCNVector3(x: 0.0015, y: 0.0015, z: 0.0015),
           
           displayedName: "Neptune",
           imgName: "neptune",
           planetImgName: "neptunePlanet",
           planetImgCaption: "Photo of Neptune",
           
           information: "Neptune is the most distant planet from the Sun. Neptune's gravity is almost Earth like, being only 17% stronger. Neptune is about 4 times wider than Earth, and it takes 165 Earth years for Neptune is orbit the Sun.",
           facts: ["Neptune has the strongest winds in the Solar System", "Neptune has 14 moons", "Neptune is an ice giant"])
]
