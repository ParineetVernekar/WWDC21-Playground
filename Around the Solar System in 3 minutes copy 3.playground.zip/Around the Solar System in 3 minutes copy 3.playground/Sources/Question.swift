
import Foundation

public struct Question{

    
    public let questionTitle : String
    public let correctAnswer : String
    public let imageAddress : String
    public let answers : [Answer]
    public let topic : String
    
    public init(questionTitle: String, correctAnswer: String, imageAddress: String, answers: [Answer], topic : String) {
        self.questionTitle = questionTitle
        self.correctAnswer = correctAnswer
        self.imageAddress = imageAddress
        self.answers = answers
        self.topic = topic 
    }
}
