import Foundation

/*:
 # Around the Solar System in 3 minutes
 I hope you enjoyed this playground, and I hope you learned all about our Solar System. Thank you for taking the time to use it, and I hope it all ran smooothly.
 By Parineet Vernekar, age 14.
*/
