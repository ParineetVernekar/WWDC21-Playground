import PlaygroundSupport

/*:
  - Note:
   During my testing, which was on an 4th Generation iPad Air, I noticed that Swift Playgrounds wouldn't run while 'Enable results' was set to true. Please turn off 'Enable Results' for all pages, so that the playground runs smoothly
 */

/*: 
 # Around the Solar System in 3 minutes
Welcome to my playground! I'm Parineet Vernekar, a 14 year old iOS developer from the United Kingdom.  I love programming, and it's one of my favourite hobbies! Over the last 3 years, I've been using Swift and during the COVID-19 pandemic, I created my first app. It was a COVID-19 tracking application for the UK, however due to it being a health related app, it was unfortunately rejected by App Review. Nonetheless, it was an incredible experience and I learned so much!
 Later on in the year, I created my first full iOS app, called School Work Organiser. It's hosted on my dad's developer account, due to me being under 16.
 This playground was created using SwiftUI, UIKit, SceneKit and ARKit, to produce a playground all about space! I hope you enjoy it, and it works as expected!
 
 Select a level on the right to get started, or go to the next page!
 */

/*:
 Credits:
 Images to form the textures of each planet are from: https://www.solarsystemscope.com/textures/
 
 Images of each planet used in the PlanetInfoView are from https://www.nasa.gov/
 
 Information about each planet is from https://www.nasa.gov/ and https://theplanets.org/
 */

PlaygroundPage.current.setLiveView(IntroView())

//: [Level 1 - AR](@next)
